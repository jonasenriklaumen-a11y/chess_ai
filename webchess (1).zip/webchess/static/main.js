/* ============================================================
   Schach-Frontend
   - Rendert das Brett als 8x8 Grid
   - Figuren als eingebettete SVG-Data-URIs (kein Bildordner nötig)
   - Kommuniziert mit den Flask-Endpunkten aus app.py
   ============================================================ */

const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"];

// Einfache, klare SVG-Figuren (Unicode-Glyphen als Pfad wäre komplex;
// wir nutzen stattdessen gut lesbare Unicode-Schachsymbole in einem
// gestylten span statt Bilddateien, das läuft garantiert ohne Assets).
const PIECE_GLYPHS = {
  wK: "♔", wQ: "♕", wR: "♖", wB: "♗", wN: "♘", wP: "♙",
  bK: "♚", bQ: "♛", bR: "♜", bB: "♝", bN: "♞", bP: "♟",
};

let state = {
  pieces: {},
  turn: "w",
  human_color: "w",
  is_game_over: false,
  status: null,
  history: [],
  legal_moves: [],
};

let selectedSquare = null;
let legalTargets = [];

const boardEl = document.getElementById("board");
const rankLabelsEl = document.getElementById("rank-labels");
const fileLabelsEl = document.getElementById("file-labels");
const overlayEl = document.getElementById("overlay");
const overlayTitleEl = document.getElementById("overlay-title");
const overlaySubEl = document.getElementById("overlay-sub");
const turnIndicatorEl = document.getElementById("turn-indicator");
const statusLineEl = document.getElementById("status-line");
const historyListEl = document.getElementById("history-list");

let chosenColor = "w";

function squareName(fileIdx, rankIdx) {
  // rankIdx 0 => rank 8 (top) when human is white
  return FILES[fileIdx] + rankIdx;
}

function buildBoardSquares() {
  boardEl.innerHTML = "";
  const humanWhite = state.human_color === "w";

  const rankOrder = humanWhite ? [8, 7, 6, 5, 4, 3, 2, 1] : [1, 2, 3, 4, 5, 6, 7, 8];
  const fileOrder = humanWhite ? [0, 1, 2, 3, 4, 5, 6, 7] : [7, 6, 5, 4, 3, 2, 1, 0];

  for (const rank of rankOrder) {
    for (const fIdx of fileOrder) {
      const file = FILES[fIdx];
      const name = file + rank;
      const isLight = (fIdx + rank) % 2 === 1;

      const sq = document.createElement("div");
      sq.className = "square " + (isLight ? "light" : "dark");
      sq.dataset.square = name;
      sq.tabIndex = 0;

      const piece = state.pieces[name];
      if (piece) {
        const span = document.createElement("span");
        span.className = "piece-glyph " + (piece.color === "w" ? "piece-white" : "piece-black");
        span.textContent = PIECE_GLYPHS[piece.color + piece.type];
        sq.appendChild(span);
        sq.classList.add("has-piece-cell");
      }

      sq.addEventListener("click", () => onSquareClick(name));
      boardEl.appendChild(sq);
    }
  }

  renderLabels(rankOrder, fileOrder);
  applySelectionStyles();
}

function renderLabels(rankOrder, fileOrder) {
  rankLabelsEl.innerHTML = "";
  rankOrder.forEach((r) => {
    const d = document.createElement("div");
    d.textContent = r;
    rankLabelsEl.appendChild(d);
  });
  fileLabelsEl.innerHTML = "";
  fileOrder.forEach((fIdx) => {
    const d = document.createElement("div");
    d.textContent = FILES[fIdx];
    fileLabelsEl.appendChild(d);
  });
}

function applySelectionStyles() {
  const squares = boardEl.querySelectorAll(".square");
  squares.forEach((sq) => {
    sq.classList.remove("selected", "legal", "has-piece", "last-move");
    const name = sq.dataset.square;
    if (name === selectedSquare) sq.classList.add("selected");
    if (legalTargets.includes(name)) {
      sq.classList.add("legal");
      if (state.pieces[name]) sq.classList.add("has-piece");
    }
    const lastMoveSquares = getLastMoveSquares();
    if (lastMoveSquares.includes(name)) sq.classList.add("last-move");
  });
}

function getLastMoveSquares() {
  // We don't get UCI of last move directly from server state; skip highlighting
  // beyond selection unless we track it client-side during move sending.
  return window.__lastMoveSquares || [];
}

function onSquareClick(name) {
  if (state.is_game_over) return;
  if (state.turn !== state.human_color) return;

  const piece = state.pieces[name];

  if (selectedSquare === null) {
    if (piece && piece.color === state.human_color) {
      selectedSquare = name;
      legalTargets = computeLegalTargets(name);
      applySelectionStyles();
    }
    return;
  }

  if (name === selectedSquare) {
    selectedSquare = null;
    legalTargets = [];
    applySelectionStyles();
    return;
  }

  if (piece && piece.color === state.human_color) {
    selectedSquare = name;
    legalTargets = computeLegalTargets(name);
    applySelectionStyles();
    return;
  }

  if (legalTargets.includes(name)) {
    const uci = buildUci(selectedSquare, name);
    window.__lastMoveSquares = [selectedSquare, name];
    selectedSquare = null;
    legalTargets = [];
    sendMove(uci);
  }
}

function buildUci(from, to) {
  // Handle simple promotion: default to queen if pawn reaches last rank
  const piece = state.pieces[from];
  let promo = "";
  if (piece && piece.type === "P") {
    const toRank = parseInt(to[1], 10);
    if ((piece.color === "w" && toRank === 8) || (piece.color === "b" && toRank === 1)) {
      promo = "q";
    }
  }
  return from + to + promo;
}

function computeLegalTargets(from) {
  return state.legal_moves
    .filter((m) => m.startsWith(from))
    .map((m) => m.slice(2, 4));
}

function setOverlay(visible, title, sub) {
  overlayEl.classList.toggle("visible", visible);
  if (title) overlayTitleEl.textContent = title;
  if (sub) overlaySubEl.textContent = sub;
}

function updateSidebar() {
  if (state.is_game_over) {
    turnIndicatorEl.textContent = "Partie beendet";
  } else {
    turnIndicatorEl.textContent = state.turn === state.human_color ? "Du bist am Zug" : "KI denkt nach …";
  }
  statusLineEl.textContent = state.status || "Bewege eine Figur, um zu ziehen.";

  historyListEl.innerHTML = "";
  state.history.forEach((san, i) => {
    const li = document.createElement("li");
    if (i % 2 === 0) {
      li.innerHTML = `<b>${san}</b>`;
    } else {
      li.textContent = san;
    }
    historyListEl.appendChild(li);
  });
  historyListEl.scrollTop = historyListEl.scrollHeight;

  if (state.is_game_over) {
    let title = "Partie beendet";
    let sub = state.status || "";
    setOverlay(true, title, sub);
  } else {
    setOverlay(false);
  }
}

function render() {
  buildBoardSquares();
  updateSidebar();
}

async function fetchJSON(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Serverfehler");
  }
  return res.json();
}

async function loadState() {
  state = await fetchJSON("/api/state");
  render();
}

async function sendMove(uci) {
  try {
    state = await fetchJSON("/api/move", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ move: uci }),
    });
    render();
    refreshStats();
  } catch (e) {
    statusLineEl.textContent = e.message;
  }
}

async function newGame(color) {
  window.__lastMoveSquares = [];
  state = await fetchJSON("/api/new_game", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ color }),
  });
  render();
  refreshStats();
}

async function resign() {
  await fetchJSON("/api/resign", { method: "POST" });
  await loadState();
  refreshStats();
}

async function refreshStats() {
  const stats = await fetchJSON("/api/stats");
  document.getElementById("stat-games").textContent = stats.games_played;
  document.getElementById("stat-wins").textContent = stats.wins;
  document.getElementById("stat-losses").textContent = stats.losses;
  document.getElementById("stat-depth").textContent = stats.search_depth;
  document.getElementById("stat-learned").textContent = stats.learned_positions;
  const weightEl = document.getElementById("stat-weight");
  if (weightEl) weightEl.textContent = stats.learning_weight;
}

/* ---------------- Event wiring ---------------- */

document.querySelectorAll(".color-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".color-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    chosenColor = btn.dataset.color;
  });
});

document.getElementById("new-game-btn").addEventListener("click", () => {
  newGame(chosenColor);
});

document.getElementById("overlay-again").addEventListener("click", () => {
  newGame(chosenColor);
});

document.getElementById("resign-btn").addEventListener("click", () => {
  if (!state.is_game_over) resign();
});

loadState();
