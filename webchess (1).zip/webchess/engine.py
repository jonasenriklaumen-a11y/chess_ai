"""
Schach-KI-Engine: Minimax mit Alpha-Beta-Suche + lernende Stellungsbewertung.
Diese Version lernt deutlich schneller als das Original:
  - höhere Grund-Lernrate pro Partie
  - stärkere Verstärkung für Züge, die kurz vor Sieg/Niederlage gespielt wurden
    (rezente Züge in der Partie beeinflussen das Ergebnis am meisten)
  - schnellerer Anstieg des Lerngewichts (learning_weight) mit der Zahl der Partien
  - schnellerer Anstieg der Suchtiefe
"""

import json
import os
import random
import chess

PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 0,
}

PAWN_TABLE = [
    0, 0, 0, 0, 0, 0, 0, 0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
    5, 5, 10, 25, 25, 10, 5, 5,
    0, 0, 0, 20, 20, 0, 0, 0,
    5, -5, -10, 0, 0, -10, -5, 5,
    5, 10, 10, -20, -20, 10, 10, 5,
    0, 0, 0, 0, 0, 0, 0, 0,
]
KNIGHT_TABLE = [
    -50, -40, -30, -30, -30, -30, -40, -50,
    -40, -20, 0, 0, 0, 0, -20, -40,
    -30, 0, 10, 15, 15, 10, 0, -30,
    -30, 5, 15, 20, 20, 15, 5, -30,
    -30, 0, 15, 20, 20, 15, 0, -30,
    -30, 5, 10, 15, 15, 10, 5, -30,
    -40, -20, 0, 5, 5, 0, -20, -40,
    -50, -40, -30, -30, -30, -30, -40, -50,
]
BISHOP_TABLE = [
    -20, -10, -10, -10, -10, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 10, 10, 10, 10, 0, -10,
    -10, 5, 5, 10, 10, 5, 5, -10,
    -10, 0, 10, 10, 10, 10, 0, -10,
    -10, 10, 10, 10, 10, 10, 10, -10,
    -10, 5, 0, 0, 0, 0, 5, -10,
    -20, -10, -10, -10, -10, -10, -10, -20,
]
ROOK_TABLE = [
    0, 0, 0, 0, 0, 0, 0, 0,
    5, 10, 10, 10, 10, 10, 10, 5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    0, 0, 0, 5, 5, 0, 0, 0,
]
QUEEN_TABLE = [
    -20, -10, -10, -5, -5, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 5, 5, 5, 5, 0, -10,
    -5, 0, 5, 5, 5, 5, 0, -5,
    0, 0, 5, 5, 5, 5, 0, -5,
    -10, 5, 5, 5, 5, 5, 0, -10,
    -10, 0, 5, 0, 0, 0, 0, -10,
    -20, -10, -10, -5, -5, -10, -10, -20,
]
KING_TABLE = [
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -20, -30, -30, -40, -40, -30, -30, -20,
    -10, -20, -20, -20, -20, -20, -20, -10,
    20, 20, 0, 0, 0, 0, 20, 20,
    20, 30, 10, 0, 0, 10, 30, 20,
]

PIECE_TABLES = {
    chess.PAWN: PAWN_TABLE,
    chess.KNIGHT: KNIGHT_TABLE,
    chess.BISHOP: BISHOP_TABLE,
    chess.ROOK: ROOK_TABLE,
    chess.QUEEN: QUEEN_TABLE,
    chess.KING: KING_TABLE,
}


class Memory:
    """Persistente Erfahrung der KI über gespielte Partien.

    Schneller lernende Variante:
      - BASE_DELTA ist deutlich höher als im Original (war 3.0 -> jetzt 6.0)
      - Züge, die näher am Partieende liegen, bekommen mehr Gewicht
        (recency-weighting), weil sie meist entscheidender für Sieg/Niederlage waren
      - learning_weight() steigt schneller mit der Anzahl gespielter Partien
      - search_depth() erreicht die Maximaltiefe früher
    """

    BASE_DELTA = 6.0        # war 3.0 im Original -> doppelt so starke Verstärkung
    DRAW_DELTA = 1.0        # war 0.5 -> auch Remis liefert mehr Lernsignal

    def __init__(self, path):
        self.path = path
        self.data = {
            "games_played": 0,
            "wins": 0,
            "losses": 0,
            "draws": 0,
            "position_scores": {},
        }
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    self.data.update(loaded)
            except (json.JSONDecodeError, OSError):
                pass

    def save(self):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2)

    @staticmethod
    def position_key(board):
        parts = board.fen().split(" ")
        return " ".join(parts[:4])

    def get_position_bonus(self, board):
        key = self.position_key(board)
        return self.data["position_scores"].get(key, 0)

    def reinforce(self, fen_keys_ai_perspective, result_for_ai):
        """Verstärkt gespielte Stellungen.

        Neu: Züge gegen Ende der Partie (näher am Ergebnis) werden stärker
        verstärkt als frühe Eröffnungszüge -> die KI lernt schneller, WAS
        konkret zum Sieg/zur Niederlage geführt hat, statt alles gleich zu
        gewichten.
        """
        if result_for_ai == 0:
            base = self.DRAW_DELTA
        else:
            base = self.BASE_DELTA * result_for_ai

        n = max(len(fen_keys_ai_perspective), 1)
        for i, key in enumerate(fen_keys_ai_perspective):
            # Recency-Faktor: 0.5 (erster Zug der Partie) bis 1.5 (letzter Zug)
            recency = 0.5 + (i + 1) / n
            delta = (base * recency) / n
            old = self.data["position_scores"].get(key, 0)
            self.data["position_scores"][key] = old + delta

    def record_result(self, result_for_ai):
        self.data["games_played"] += 1
        if result_for_ai > 0:
            self.data["wins"] += 1
        elif result_for_ai < 0:
            self.data["losses"] += 1
        else:
            self.data["draws"] += 1

    def search_depth(self):
        games = self.data["games_played"]
        # schnellerer Anstieg als im Original (war < 3 / < 10)
        if games < 2:
            return 2
        elif games < 5:
            return 3
        elif games < 12:
            return 4
        else:
            return 5

    def learning_weight(self):
        games = self.data["games_played"]
        # war: 1.0 + games * 0.15, Obergrenze 8.0
        # jetzt: schnellerer Anstieg (0.35 pro Partie) und höhere Obergrenze
        return min(1.0 + games * 0.35, 12.0)

    def summary(self):
        d = self.data
        return {
            "games_played": d["games_played"],
            "wins": d["wins"],
            "losses": d["losses"],
            "draws": d["draws"],
            "search_depth": self.search_depth(),
            "learning_weight": round(self.learning_weight(), 2),
            "learned_positions": len(d["position_scores"]),
        }


def evaluate_material_and_position(board):
    if board.is_checkmate():
        return -99999 if board.turn == chess.WHITE else 99999
    if board.is_stalemate() or board.is_insufficient_material():
        return 0

    score = 0
    for square in chess.SQUARES:
        piece = board.piece_at(square)
        if piece is None:
            continue
        value = PIECE_VALUES[piece.piece_type]
        table = PIECE_TABLES[piece.piece_type]
        idx = square if piece.color == chess.WHITE else chess.square_mirror(square)
        pos_bonus = table[idx]
        total = value + pos_bonus
        score += total if piece.color == chess.WHITE else -total

    score += 2 * len(list(board.legal_moves)) if board.turn == chess.WHITE else -2 * len(list(board.legal_moves))
    return score


def evaluate(board, memory, ai_color, learning_weight):
    raw = evaluate_material_and_position(board)
    score_for_ai = raw if ai_color == chess.WHITE else -raw
    learned = memory.get_position_bonus(board) * learning_weight
    return score_for_ai + learned


def minimax(board, depth, alpha, beta, maximizing, memory, ai_color, learning_weight):
    if depth == 0 or board.is_game_over():
        return evaluate(board, memory, ai_color, learning_weight), None

    best_move = None
    legal_moves = list(board.legal_moves)
    random.shuffle(legal_moves)

    if maximizing:
        max_eval = float("-inf")
        for move in legal_moves:
            board.push(move)
            eval_score, _ = minimax(board, depth - 1, alpha, beta, False, memory, ai_color, learning_weight)
            board.pop()
            if eval_score > max_eval:
                max_eval = eval_score
                best_move = move
            alpha = max(alpha, eval_score)
            if beta <= alpha:
                break
        return max_eval, best_move
    else:
        min_eval = float("inf")
        for move in legal_moves:
            board.push(move)
            eval_score, _ = minimax(board, depth - 1, alpha, beta, True, memory, ai_color, learning_weight)
            board.pop()
            if eval_score < min_eval:
                min_eval = eval_score
                best_move = move
            beta = min(beta, eval_score)
            if beta <= alpha:
                break
        return min_eval, best_move


def ai_choose_move(board, memory, ai_color):
    depth = memory.search_depth()
    weight = memory.learning_weight()
    _, move = minimax(board, depth, float("-inf"), float("inf"), True, memory, ai_color, weight)
    if move is None:
        legal = list(board.legal_moves)
        move = random.choice(legal) if legal else None
    return move


def game_result_for_ai(board, ai_color):
    result = board.result(claim_draw=True)
    if result == "1-0":
        return 1 if ai_color == chess.WHITE else -1
    elif result == "0-1":
        return 1 if ai_color == chess.BLACK else -1
    else:
        return 0
