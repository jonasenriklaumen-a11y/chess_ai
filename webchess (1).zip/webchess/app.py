"""
Web-Schach gegen eine lernende KI.
Start: python app.py  -> öffnet auf http://localhost:5000
"""

import os
import socket
import uuid
import chess
from flask import Flask, render_template, request, jsonify, session

import engine

app = Flask(__name__)
app.secret_key = "chess-local-dev-secret"  # nur für lokale Nutzung

MEMORY_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chess_ai_memory.json")
memory = engine.Memory(MEMORY_PATH)

# In-Memory-Spielzustand pro Browser-Session (nur für lokale Nutzung ausreichend)
GAMES = {}


def get_game():
    if "game_id" not in session:
        session["game_id"] = str(uuid.uuid4())
    gid = session["game_id"]
    if gid not in GAMES:
        GAMES[gid] = {
            "board": chess.Board(),
            "human_color": chess.WHITE,
            "ai_keys": [],
            "history": [],  # Liste von SAN-Strings
            "game_over_recorded": False,
        }
    return GAMES[gid]


def board_state(game):
    board = game["board"]
    pieces = {}
    for square in chess.SQUARES:
        piece = board.piece_at(square)
        if piece:
            pieces[chess.square_name(square)] = {
                "type": piece.symbol().upper(),
                "color": "w" if piece.color == chess.WHITE else "b",
            }

    status = None
    if board.is_checkmate():
        winner = "Schwarz" if board.turn == chess.WHITE else "Weiß"
        status = f"Schachmatt! {winner} gewinnt."
    elif board.is_stalemate():
        status = "Patt! Remis."
    elif board.is_insufficient_material():
        status = "Remis (unzureichendes Material)."
    elif board.can_claim_draw():
        status = "Remis möglich (Zugwiederholung/50-Züge-Regel)."
    elif board.is_check():
        status = "Schach!"

    return {
        "pieces": pieces,
        "turn": "w" if board.turn == chess.WHITE else "b",
        "human_color": "w" if game["human_color"] == chess.WHITE else "b",
        "is_game_over": board.is_game_over(claim_draw=True),
        "status": status,
        "history": game["history"],
        "legal_moves": [m.uci() for m in board.legal_moves],
    }


@app.route("/")
def index():
    return render_template("index.html", stats=memory.summary())


@app.route("/api/state")
def api_state():
    game = get_game()
    return jsonify(board_state(game))


@app.route("/api/new_game", methods=["POST"])
def api_new_game():
    data = request.get_json(force=True)
    human_color = chess.WHITE if data.get("color", "w") == "w" else chess.BLACK

    session["game_id"] = str(uuid.uuid4())
    gid = session["game_id"]
    GAMES[gid] = {
        "board": chess.Board(),
        "human_color": human_color,
        "ai_keys": [],
        "history": [],
        "game_over_recorded": False,
    }
    game = GAMES[gid]

    # Falls KI Weiß spielt, macht sie den ersten Zug
    if game["human_color"] == chess.BLACK:
        ai_move(game)

    return jsonify(board_state(game))


def ai_move(game):
    board = game["board"]
    ai_color = not game["human_color"]
    if board.is_game_over(claim_draw=True):
        return
    move = engine.ai_choose_move(board, memory, ai_color)
    if move is None:
        return
    san = board.san(move)
    board.push(move)
    game["ai_keys"].append(memory.position_key(board))
    game["history"].append(san)


def finalize_if_over(game):
    board = game["board"]
    if board.is_game_over(claim_draw=True) and not game["game_over_recorded"]:
        ai_color = not game["human_color"]
        result = engine.game_result_for_ai(board, ai_color)
        memory.reinforce(game["ai_keys"], result)
        memory.record_result(result)
        memory.save()
        game["game_over_recorded"] = True


@app.route("/api/move", methods=["POST"])
def api_move():
    game = get_game()
    board = game["board"]
    data = request.get_json(force=True)
    uci = data.get("move", "")

    if board.turn != game["human_color"]:
        return jsonify({"error": "Nicht dein Zug."}), 400

    try:
        move = chess.Move.from_uci(uci)
    except ValueError:
        return jsonify({"error": "Ungültiger Zug."}), 400

    if move not in board.legal_moves:
        return jsonify({"error": "Illegaler Zug."}), 400

    san = board.san(move)
    board.push(move)
    game["history"].append(san)

    finalize_if_over(game)

    if not board.is_game_over(claim_draw=True):
        ai_move(game)
        finalize_if_over(game)

    return jsonify(board_state(game))


@app.route("/api/resign", methods=["POST"])
def api_resign():
    game = get_game()
    if not game["game_over_recorded"]:
        # Aufgabe zählt als KI-Sieg
        memory.reinforce(game["ai_keys"], result_for_ai=1)
        memory.record_result(result_for_ai=1)
        memory.save()
        game["game_over_recorded"] = True
    return jsonify({"stats": memory.summary()})


@app.route("/api/stats")
def api_stats():
    return jsonify(memory.summary())


def get_lan_ip():
    """Ermittelt die lokale LAN-IP dieses Rechners (best effort)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Verbindet sich nicht wirklich, dient nur dazu, die passende
        # Netzwerkschnittstelle/IP herauszufinden.
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except OSError:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


if __name__ == "__main__":
    lan_ip = get_lan_ip()
    print("=" * 60)
    print(" Web-Schach gegen eine lernende KI")
    print(" Auf diesem Rechner öffnen:  http://localhost:5000")
    print(f" Im Heimnetz (LAN) öffnen:   http://{lan_ip}:5000")
    print(" (Andere Geräte müssen im selben WLAN/Netzwerk sein.")
    print("  Falls die Verbindung nicht klappt, ggf. die Firewall")
    print("  für Port 5000 freigeben.)")
    print("=" * 60)
    app.run(host="0.0.0.0", port=5000, debug=False)
