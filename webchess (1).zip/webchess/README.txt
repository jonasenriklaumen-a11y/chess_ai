SCHACH GEGEN DIE LERNENDE KI — WEB-VERSION (schneller lernend + neues Design)
=============================================================================

WAS IST NEU:
  - Der Server ist jetzt im LAN (Heimnetz) erreichbar, nicht mehr nur auf
    dem eigenen Rechner. Beim Start zeigt das Terminal eine Adresse wie
    http://192.168.x.x:5000 an — die kannst du auf Handy/Tablet/anderem
    PC im selben WLAN im Browser öffnen und mitspielen.
  - engine.py lernt jetzt deutlich schneller:
      * höhere Grund-Lernrate pro Partie (BASE_DELTA 3.0 -> 6.0)
      * Züge kurz vor Sieg/Niederlage werden stärker verstärkt (Recency-Gewichtung)
      * Suchtiefe steigt schneller mit der Anzahl Partien (2 -> 3 -> 4 -> 5)
      * Lerngewicht steigt schneller (0.35 pro Partie statt 0.15), Obergrenze 12.0
  - Neues Design: dunkles, ruhiges Apple-artiges UI (Glaspanels, Serifen-Headlines)
    kombiniert mit einem klassischen chess.com-Brett (Grün/Creme, klare Figuren)

INSTALLATION (einmalig):
  pip install flask python-chess
  (falls Fehlermeldung "externally managed environment":)
  pip install flask python-chess --break-system-packages

ORDNERSTRUKTUR (alle Dateien/Ordner müssen zusammenbleiben!):
  webchess/
    app.py
    engine.py
    chess_ai_memory.json
    templates/
      index.html
    static/
      style.css
      main.js

STARTEN:
  1. Terminal/PowerShell öffnen
  2. In den "webchess"-Ordner wechseln, z. B.:
       cd Downloads\webchess
  3. Server starten:
       python3 app.py
     (falls "python3" nicht erkannt wird: "python app.py")
  4. Im Browser öffnen:
       http://localhost:5000
     (auf demselben Rechner)

  5. Für andere Geräte im selben WLAN/Netzwerk:
       Die im Terminal angezeigte Adresse verwenden, z. B.
       http://192.168.1.23:5000
     Falls die Verbindung nicht klappt, blockiert evtl. die
     Windows-/Mac-Firewall den Port 5000 — dann einmalig eine
     Ausnahme für Python/Port 5000 erlauben.

BEENDEN:
  Im Terminal STRG+C drücken.

FORTSCHRITT:
  Die KI speichert ihre Erfahrung automatisch in
  webchess/chess_ai_memory.json — je öfter gespielt wird,
  desto stärker und "erfahrener" wird sie (siehe Statistik-Leiste oben).
